"""
ZoomInfo REST API contact enrichment.
Replaces the MCP-based enrichment used in the Claude skill.
"""

import requests
import time
from typing import Callable, Dict, List, Optional

ZI_AUTH_URL   = "https://api.zoominfo.com/authenticate"
ZI_ENRICH_URL = "https://api.zoominfo.com/enrich/contact"


def get_token(username: str, password: str, client_id: str = "") -> str:
    """Authenticate with ZoomInfo and return a JWT access token."""
    payload: dict = {"username": username, "password": password}
    if client_id:
        payload["client_id"] = client_id
    r = requests.post(ZI_AUTH_URL, json=payload, timeout=30)
    r.raise_for_status()
    data = r.json()
    token = data.get("jwt") or data.get("token") or data.get("access_token")
    if not token:
        raise ValueError(
            f"No token in ZoomInfo auth response. Keys: {list(data.keys())}. "
            "Verify your credentials and that the ZoomInfo API is enabled on your account."
        )
    return token


def _extract_email(entry: dict) -> Optional[str]:
    """Extract email from a result entry, handling multiple ZoomInfo response shapes."""
    data = entry.get("data")
    if isinstance(data, list) and data:
        return data[0].get("email") or None
    if isinstance(data, dict):
        return data.get("email") or None
    return entry.get("email") or None


def _enrich_batch(contacts: List[dict], token: str) -> Dict[str, Optional[str]]:
    """
    Send one batch to ZoomInfo /enrich/contact.
    Returns {key: email_or_None} keyed by linkedin_url.lower() or "First|Last|Company".
    """
    match_inputs: list = []
    keys: list = []

    for c in contacts:
        linkedin_url = (c.get("linkedin_url") or "").strip()
        first   = (c.get("first_name")   or "").strip()
        last    = (c.get("last_name")    or "").strip()
        company = (c.get("company_name") or "").strip()

        person: dict = {}
        if first:
            person["firstName"] = first
        if last:
            person["lastName"] = last
        if company:
            person["companyName"] = company
        # Note: linkedInUrl and externalURLs both cause INVALID_INPUT — ZoomInfo
        # matches on name + company only via this endpoint.
        # Key by linkedin_url for lookup compatibility; fall back to name|company.
        keys.append(linkedin_url.lower() if linkedin_url else f"{first}|{last}|{company}")

        match_inputs.append(person)

    payload = {"matchPersonInput": match_inputs, "outputFields": ["email"]}
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    r = requests.post(ZI_ENRICH_URL, headers=headers, json=payload, timeout=60)
    r.raise_for_status()
    resp = r.json()

    # ZoomInfo uses several response shapes — handle all of them:
    #   Shape A: {"data": {"result": [...]}}   ← nested dict
    #   Shape B: {"data": [...]}               ← data IS the list
    #   Shape C: {"result": [...]}             ← top-level result
    data_block = resp.get("data")
    if isinstance(data_block, list):
        result_list = data_block
    elif isinstance(data_block, dict):
        result_list = data_block.get("result", [])
    else:
        result_list = resp.get("result", [])

    # Debug: always log the response shape so issues are visible in the terminal
    if result_list:
        first = result_list[0]
        ms = first.get("matchStatus", "?") if isinstance(first, dict) else "?"
        print(f"[ZI] {len(result_list)} result(s). First matchStatus={ms!r}")
    else:
        print(f"[ZI] ⚠️  Empty result_list.")
        print(f"[ZI]    resp keys:  {list(resp.keys())}")
        print(f"[ZI]    data type:  {type(data_block).__name__}")
        print(f"[ZI]    data value: {str(data_block)[:300]}")

    enriched: Dict[str, Optional[str]] = {}
    for i, entry in enumerate(result_list):
        if i >= len(keys):
            break
        key = keys[i]
        match_status = str(entry.get("matchStatus", "")).lower().replace("_", " ")
        email = _extract_email(entry) if "full match" in match_status else None
        if email:
            print(f"[ZI] ✅  {key[:60]}  →  {email}")
        else:
            print(f"[ZI] ✗   {key[:60]}  status={match_status!r}")
        enriched[key] = email

    for key in keys:
        enriched.setdefault(key, None)

    return enriched


def _mark_batch_none(batch, enriched, error_msg, cb, batch_idx, total_batches):
    """Mark all contacts in a failed batch as no-match."""
    if cb:
        cb(
            f"⚠️  Batch {batch_idx + 1} failed ({error_msg[:80]}) — marked as no-match.",
            batch_idx, total_batches,
        )
    for c in batch:
        url = (c.get("linkedin_url") or "").lower().strip()
        key = url if url else (
            f"{(c.get('first_name') or '').strip()}|"
            f"{(c.get('last_name') or '').strip()}|"
            f"{(c.get('company_name') or '').strip()}"
        )
        enriched.setdefault(key, None)


def enrich_contacts_batch(
    contacts: List[dict],
    username: str,
    password: str,
    client_id: str = "",
    batch_size: int = 10,
    progress_callback: Optional[Callable] = None,
) -> Dict[str, Optional[str]]:
    """
    Enrich a list of contacts via the ZoomInfo REST API.

    Args:
        contacts:          list of {linkedin_url, first_name, last_name, company_name}
        username/password: ZoomInfo credentials
        client_id:         optional, required by some ZoomInfo plans
        batch_size:        contacts per API call (10 matches the original skill)
        progress_callback: called as callback(message_str, batches_done, total_batches)

    Returns:
        dict mapping linkedin_url.lower() (or "First|Last|Company") → email or None
    """
    if not contacts:
        return {}

    token         = get_token(username, password, client_id)
    all_enriched: Dict[str, Optional[str]] = {}
    total         = len(contacts)
    total_batches = (total + batch_size - 1) // batch_size

    for batch_idx in range(total_batches):
        batch = contacts[batch_idx * batch_size: (batch_idx + 1) * batch_size]

        if progress_callback:
            progress_callback(
                f"Batch {batch_idx + 1}/{total_batches}  ({len(batch)} contacts)…",
                batch_idx, total_batches,
            )

        try:
            all_enriched.update(_enrich_batch(batch, token))

        except requests.HTTPError as exc:
            if exc.response is not None and exc.response.status_code == 401:
                if progress_callback:
                    progress_callback("Token expired — re-authenticating…", batch_idx, total_batches)
                token = get_token(username, password, client_id)
                try:
                    all_enriched.update(_enrich_batch(batch, token))
                except Exception as inner:
                    _mark_batch_none(batch, all_enriched, str(inner), progress_callback, batch_idx, total_batches)
            else:
                _mark_batch_none(batch, all_enriched, str(exc), progress_callback, batch_idx, total_batches)

        except Exception as exc:
            _mark_batch_none(batch, all_enriched, str(exc), progress_callback, batch_idx, total_batches)

        time.sleep(0.2)

    found = sum(1 for v in all_enriched.values() if v)
    if progress_callback:
        progress_callback(f"Done — {found}/{total} emails found.", total_batches, total_batches)

    return all_enriched
